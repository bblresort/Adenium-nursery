import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const SUPABASE_URL = 'https://omtvdwymzmvrukrgjrmj.supabase.co';
const SUPABASE_KEY = 'sb_publishable_ZAAjScf5NsSskFrErLbVkA_wlSZeFXp';
const sb = createClient(SUPABASE_URL, SUPABASE_KEY);

let user = null;
let business = null;
let syncing = false;

const overlay = () => document.getElementById('authOverlay');
const authMsg = (text, error=false) => {
  const el=document.getElementById('authMessage');
  if(el) el.innerHTML=`<div class="message ${error?'error':'success'}">${text}</div>`;
};

function setCloudStatus(ok, text){
  const fy=document.getElementById('fyLabel');
  if(!fy) return;
  fy.innerHTML=`<span class="cloud-status"><span class="dot ${ok?'ok':''}"></span>${text}</span>`;
}

window.cloudSignIn = async function(){
  const email=document.getElementById('authEmail').value.trim();
  const password=document.getElementById('authPassword').value;
  if(!email||!password) return authMsg('Enter your email and password.',true);
  const {error}=await sb.auth.signInWithPassword({email,password});
  if(error) authMsg(error.message,true);
};

window.cloudSignUp = async function(){
  const email=document.getElementById('authEmail').value.trim();
  const password=document.getElementById('authPassword').value;
  if(!email||password.length<6) return authMsg('Enter an email and a password of at least 6 characters.',true);
  const {data,error}=await sb.auth.signUp({email,password});
  if(error) return authMsg(error.message,true);
  if(data.session) authMsg('Account created. Signing you in…');
  else authMsg('Account created. Check your email to confirm it, then sign in.');
};

window.cloudSignOut = async function(){ await sb.auth.signOut(); location.reload(); };
window.cloudForgotPassword = async function(){
  const email=document.getElementById('authEmail').value.trim();
  if(!email) return authMsg('Enter your email first, then choose Forgot password.',true);
  const redirectTo=window.location.href.split('#')[0];
  const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo});
  if(error) return authMsg(error.message,true);
  authMsg('Password reset email sent. Open the link in your email to choose a new password.');
};


window.completePasswordRecovery = async function(){
  const a=document.getElementById('recoveryPassword')?.value||''; const b=document.getElementById('recoveryPassword2')?.value||''; const box=document.getElementById('recoveryMessage');
  if(a.length<8){ if(box) box.innerHTML='<div class="message error">Use at least 8 characters.</div>'; return; }
  if(a!==b){ if(box) box.innerHTML='<div class="message error">The passwords do not match.</div>'; return; }
  const {error}=await sb.auth.updateUser({password:a});
  if(error){ if(box) box.innerHTML=`<div class="message error">${error.message}</div>`; return; }
  if(box) box.innerHTML='<div class="message success">Password updated successfully.</div>';
  document.getElementById('recoveryPassword').value=''; document.getElementById('recoveryPassword2').value='';
  document.getElementById('recoveryOverlay')?.classList.add('hide'); overlay().classList.add('hide'); setCloudStatus(true,'Cloud connected');
  try{ await loadCloud(); window.__appSetup(); }catch(e){ console.error(e); }
};

window.changePassword = async function(){
  const a=document.getElementById('newPassword')?.value||'';
  const b=document.getElementById('confirmPassword')?.value||'';
  if(a.length<8) return msg('Use at least 8 characters for the new password.','error');
  if(a!==b) return msg('The new passwords do not match.','error');
  const {error}=await sb.auth.updateUser({password:a});
  if(error) return msg(error.message,'error');
  document.getElementById('newPassword').value=''; document.getElementById('confirmPassword').value='';
  msg('Password changed successfully.');
};


async function ensureBusiness(){
  const {data:rows,error}=await sb.from('businesses').select('*').eq('owner_id',user.id).limit(1);
  if(error) throw error;
  if(rows?.length){ business=rows[0]; return; }
  const s=window.data.settings;
  const row={owner_id:user.id,name:s.business||'Adenium Nursery',gstin:s.gstin||null,address:s.address||null,state:s.state||'Assam',pin:s.pin||null,phone:s.phone||null,invoice_prefix:s.prefix||'AN'};
  const {data:created,error:e}=await sb.from('businesses').insert(row).select().single();
  if(e) throw e;
  business=created;
}

async function loadCloud(){
  const localSnapshot=JSON.parse(JSON.stringify(window.data));
  await ensureBusiness();
  const bid=business.id;
  if(!window.data.accounts?.length){ window.data.accounts=JSON.parse('[{"id":"cash","name":"Cash","type":"asset","opening":0},{"id":"bank","name":"Bank","type":"asset","opening":0},{"id":"receivable","name":"Trade Receivables","type":"asset","opening":0},{"id":"payable","name":"Trade Payables","type":"liability","opening":0},{"id":"sales","name":"Sales","type":"income","opening":0},{"id":"purchases","name":"Purchases","type":"expense","opening":0},{"id":"gst-output","name":"GST Output","type":"liability","opening":0},{"id":"gst-input","name":"GST Input","type":"asset","opening":0},{"id":"expense","name":"Operating Expenses","type":"expense","opening":0},{"id":"capital","name":"Owner Capital","type":"equity","opening":0}]'); }
  const [p,c,i,m,sup,pu,q,so,po,dc,ex,ac,je]=await Promise.all([
    sb.from('products').select('*').eq('business_id',bid).order('name'),
    sb.from('customers').select('*').eq('business_id',bid).order('name'),
    sb.from('invoices').select('*,invoice_items(*)').eq('business_id',bid).order('invoice_date',{ascending:false}),
    sb.from('stock_movements').select('*').eq('business_id',bid).order('movement_date',{ascending:false}),
    sb.from('suppliers').select('*').eq('business_id',bid).order('name'),
    sb.from('purchases').select('*').eq('business_id',bid).order('purchase_date',{ascending:false}),
    sb.from('quotes').select('*').eq('business_id',bid).order('quote_date',{ascending:false}),
    sb.from('sales_orders').select('*').eq('business_id',bid).order('order_date',{ascending:false}),
    sb.from('purchase_orders').select('*').eq('business_id',bid).order('order_date',{ascending:false}),
    sb.from('delivery_challans').select('*').eq('business_id',bid).order('challan_date',{ascending:false}),
    sb.from('expenses').select('*').eq('business_id',bid).order('expense_date',{ascending:false}),
    sb.from('accounts').select('*').eq('business_id',bid).order('name'),
    sb.from('journal_entries').select('*').eq('business_id',bid).order('entry_date',{ascending:false})
  ]);
  for(const r of [p,c,i,m,sup,pu,q,so,po,dc,ex,ac,je]) if(r.error) throw r.error;
  const cloudIsEmpty=!(p.data?.length||c.data?.length||i.data?.length||sup.data?.length||pu.data?.length||q.data?.length||so.data?.length||po.data?.length||dc.data?.length||ex.data?.length||je.data?.length);
  if(cloudIsEmpty && (localSnapshot.invoices.length||localSnapshot.products.length||localSnapshot.customers.length)){
    Object.assign(window.data, localSnapshot);
    await syncCloud();
    return;
  }
  const s={business:business.name||'Adenium Nursery',gstin:business.gstin||'',address:business.address||'',state:business.state||'Assam',pin:business.pin||'',phone:business.phone||'',payment:window.data.settings.payment||'UPI',prefix:business.invoice_prefix||'AN'};
  const products=(p.data||[]).map(x=>({id:x.id,name:x.name,hsn:x.hsn||'',unit:x.unit||'Nos',rate:Number(x.rate)||0,gst:Number(x.gst_rate)||0,stock:Number(x.stock)||0,reorder:Number(x.reorder_level??5)||0}));
  const customers=(c.data||[]).map(x=>({id:x.id,name:x.name||'',mobile:x.mobile||'',gstin:x.gstin||'',address:x.address||'',state:x.state||'',pin:x.pin||''}));
  const invoices=(i.data||[]).map(x=>({id:x.id,status:x.status||'active',cancellationReason:x.cancellation_reason||'',cancelledAt:x.cancelled_at?new Date(x.cancelled_at).getTime():null,number:x.invoice_number,date:x.invoice_date,supplyType:x.supply_type==='inter'?'inter':'intra',reverseCharge:x.reverse_charge?'Yes':'No',customer:{name:'',mobile:'',gstin:'',address:'',state:'',pin:''},items:(x.invoice_items||[]).map(it=>({id:it.id,productId:it.product_id||null,name:it.item_name,hsn:it.hsn||'',unit:it.unit||'Nos',qty:Number(it.quantity)||0,rate:Number(it.rate)||0,discount:Number(it.discount)||0,gst:Number(it.gst_rate)||0})),subtotal:Number(x.subtotal)||0,discount:Number(x.discount_total)||0,taxable:Number(x.taxable_total)||0,cgst:Number(x.cgst_total)||0,sgst:Number(x.sgst_total)||0,igst:Number(x.igst_total)||0,grandTotal:Number(x.grand_total)||0,payment:{mode:x.payment_mode||'UPI',paid:Number(x.amount_paid)||0,balance:Number(x.balance_due)||0},note:x.note||'',createdAt:new Date(x.created_at||Date.now()).getTime()}));
  for(const inv of invoices){ const cust=(c.data||[]).find(z=>z.id===inv.customer_id); if(cust) inv.customer={id:cust.id,name:cust.name||'',mobile:cust.mobile||'',gstin:cust.gstin||'',address:cust.address||'',state:cust.state||'',pin:cust.pin||''}; }
  window.data.settings=s; window.data.products=products; window.data.customers=customers; window.data.invoices=invoices; window.data.stockMoves=(m.data||[]).map(x=>({id:x.id,productId:x.product_id,qty:Number(x.quantity_change)||0,reason:x.reason||'',date:x.movement_date,createdAt:new Date(x.created_at||Date.now()).getTime()}));
  window.data.suppliers=(sup.data||[]).map(x=>({id:x.id,name:x.name||'',mobile:x.mobile||'',gstin:x.gstin||'',state:x.state||''}));
  window.data.purchases=(pu.data||[]).map(x=>({id:x.id,number:x.number,date:x.purchase_date,supplierId:x.supplier_id,supplierName:x.supplier_name,rows:x.rows||[],total:Number(x.total)||0,balance:Number(x.balance)||0,status:x.status||'active',createdAt:new Date(x.created_at||Date.now()).getTime()}));
  window.data.quotes=(q.data||[]).map(x=>({id:x.id,number:x.number,date:x.quote_date,partyId:x.party_id,partyName:x.party_name,rows:x.rows||[],total:Number(x.total)||0,status:x.status||'open',sourceId:x.source_id,createdAt:new Date(x.created_at||Date.now()).getTime()}));
  window.data.salesOrders=(so.data||[]).map(x=>({id:x.id,number:x.number,date:x.order_date,partyId:x.party_id,partyName:x.party_name,rows:x.rows||[],total:Number(x.total)||0,status:x.status||'open',sourceQuoteId:x.source_quote_id,createdAt:new Date(x.created_at||Date.now()).getTime()}));
  window.data.purchaseOrders=(po.data||[]).map(x=>({id:x.id,number:x.number,date:x.order_date,partyId:x.party_id,partyName:x.party_name,rows:x.rows||[],total:Number(x.total)||0,status:x.status||'open',createdAt:new Date(x.created_at||Date.now()).getTime()}));
  window.data.challans=(dc.data||[]).map(x=>({id:x.id,number:x.number,date:x.challan_date,partyId:x.party_id,partyName:x.party_name,purpose:x.purpose||'',rows:x.rows||[],total:Number(x.total)||0,status:x.status||'open',sourceSalesOrderId:x.source_sales_order_id,createdAt:new Date(x.created_at||Date.now()).getTime()}));
  window.data.expenses=(ex.data||[]).map(x=>({id:x.id,date:x.expense_date,category:x.category,amount:Number(x.amount)||0,mode:x.mode||'Cash',note:x.note||'',createdAt:new Date(x.created_at||Date.now()).getTime()}));
  window.data.accounts=(ac.data||[]).map(x=>({id:x.account_key,name:x.name,type:x.type,opening:Number(x.opening)||0}));
  if(!window.data.accounts.length){ window.data.accounts=[{id:'cash',name:'Cash',type:'asset',opening:0},{id:'bank',name:'Bank',type:'asset',opening:0},{id:'receivable',name:'Trade Receivables',type:'asset',opening:0},{id:'payable',name:'Trade Payables',type:'liability',opening:0},{id:'sales',name:'Sales',type:'income',opening:0},{id:'purchases',name:'Purchases',type:'expense',opening:0},{id:'gst-output',name:'GST Output',type:'liability',opening:0},{id:'gst-input',name:'GST Input',type:'asset',opening:0},{id:'expense',name:'Operating Expenses',type:'expense',opening:0},{id:'capital',name:'Owner Capital',type:'equity',opening:0}]; }
  window.data.ledger=(je.data||[]).map(x=>({id:x.id,date:x.entry_date,description:x.description,debit:x.debit_account,credit:x.credit_account,amount:Number(x.amount)||0,ref:x.ref||'',createdAt:new Date(x.created_at||Date.now()).getTime()}));
  localStorage.setItem(window.KEY,JSON.stringify(window.data));
  if(!ac.data?.length) await syncCloud();
}


async function upsertSimple(table, rows, mapper){ if(!rows?.length) return; const r=await sb.from(table).upsert(rows.map(mapper),{onConflict:'id'}); if(r.error) throw r.error; }
async function syncCloud(){
  if(!user||!business||syncing) return;
  syncing=true;
  try{
    const d=window.data, bid=business.id;
    const bizUpdate=await sb.from('businesses').update({name:d.settings.business,gstin:d.settings.gstin||null,address:d.settings.address,state:d.settings.state,pin:d.settings.pin,phone:d.settings.phone,invoice_prefix:d.settings.prefix}).eq('id',bid); if(bizUpdate.error) throw bizUpdate.error;
    if(d.products.length){ const r=await sb.from('products').upsert(d.products.map(x=>({id:x.id,business_id:bid,name:x.name,hsn:x.hsn,unit:x.unit,rate:x.rate,gst_rate:x.gst,active:true,stock:x.stock||0,reorder_level:x.reorder??5})),{onConflict:'id'}); if(r.error) throw r.error; }
    if(d.stockMoves?.length){ const r=await sb.from('stock_movements').upsert(d.stockMoves.map(x=>({id:x.id,business_id:bid,product_id:x.productId,quantity_change:x.qty,reason:x.reason||'Manual adjustment',movement_date:x.date||new Date().toISOString().slice(0,10)})),{onConflict:'id'}); if(r.error) throw r.error; }
    if(d.customers.length){ const r=await sb.from('customers').upsert(d.customers.map(x=>({id:x.id,business_id:bid,name:x.name,mobile:x.mobile||null,gstin:x.gstin||null,address:x.address||null,state:x.state||null,pin:x.pin||null})),{onConflict:'id'}); if(r.error) throw r.error; }
    if(d.suppliers?.length){ const r=await sb.from('suppliers').upsert(d.suppliers.map(x=>({id:x.id,business_id:bid,name:x.name,mobile:x.mobile||null,gstin:x.gstin||null,state:x.state||null})),{onConflict:'id'}); if(r.error) throw r.error; }
    if(d.quotes?.length){ const r=await sb.from('quotes').upsert(d.quotes.map(x=>({id:x.id,business_id:bid,number:x.number,quote_date:x.date,party_id:x.partyId||null,party_name:x.partyName,rows:x.rows,total:x.total||0,status:x.status||'open',source_id:x.sourceId||null})),{onConflict:'id'}); if(r.error) throw r.error; }
    if(d.salesOrders?.length){ const r=await sb.from('sales_orders').upsert(d.salesOrders.map(x=>({id:x.id,business_id:bid,number:x.number,order_date:x.date,party_id:x.partyId||null,party_name:x.partyName,rows:x.rows,total:x.total||0,status:x.status||'open',source_quote_id:x.sourceQuoteId||null})),{onConflict:'id'}); if(r.error) throw r.error; }
    if(d.purchaseOrders?.length){ const r=await sb.from('purchase_orders').upsert(d.purchaseOrders.map(x=>({id:x.id,business_id:bid,number:x.number,order_date:x.date,party_id:x.partyId||null,party_name:x.partyName,rows:x.rows,total:x.total||0,status:x.status||'open'})),{onConflict:'id'}); if(r.error) throw r.error; }
    if(d.challans?.length){ const r=await sb.from('delivery_challans').upsert(d.challans.map(x=>({id:x.id,business_id:bid,number:x.number,challan_date:x.date,party_id:x.partyId||null,party_name:x.partyName,purpose:x.purpose||null,rows:x.rows||[],total:x.total||0,status:x.status||'open',source_sales_order_id:x.sourceSalesOrderId||null})),{onConflict:'id'}); if(r.error) throw r.error; }
    if(d.purchases?.length){ const r=await sb.from('purchases').upsert(d.purchases.map(x=>({id:x.id,business_id:bid,number:x.number,purchase_date:x.date,supplier_id:x.supplierId||null,supplier_name:x.supplierName,rows:x.rows||[],total:x.total||0,balance:x.balance||0,status:x.status||'active'})),{onConflict:'id'}); if(r.error) throw r.error; }
    if(d.expenses?.length){ const r=await sb.from('expenses').upsert(d.expenses.map(x=>({id:x.id,business_id:bid,expense_date:x.date,category:x.category,amount:x.amount||0,mode:x.mode||'Cash',note:x.note||null})),{onConflict:'id'}); if(r.error) throw r.error; }
    if(d.accounts?.length){ const r=await sb.from('accounts').upsert(d.accounts.map(x=>({business_id:bid,account_key:x.id,name:x.name,type:x.type,opening:x.opening||0})),{onConflict:'business_id,account_key'}); if(r.error) throw r.error; }
    if(d.ledger?.length){ const r=await sb.from('journal_entries').upsert(d.ledger.map(x=>({id:x.id,business_id:bid,entry_date:x.date,description:x.description,debit_account:x.debit,credit_account:x.credit,amount:x.amount||0,ref:x.ref||null})),{onConflict:'id'}); if(r.error) throw r.error; }
    for(const inv of d.invoices){
      const customerId=inv.customer?.id||null;
      const ir=await sb.from('invoices').upsert({id:inv.id,business_id:bid,customer_id:customerId,invoice_number:inv.number,invoice_date:inv.date,supply_type:inv.supplyType,reverse_charge:inv.reverseCharge==='Yes',status:inv.status||'active',cancellation_reason:inv.cancellationReason||null,cancelled_at:inv.cancelledAt?new Date(inv.cancelledAt).toISOString():null,subtotal:inv.subtotal,discount_total:inv.discount,taxable_total:inv.taxable,cgst_total:inv.cgst,sgst_total:inv.sgst,igst_total:inv.igst,grand_total:inv.grandTotal,payment_mode:inv.payment.mode,amount_paid:inv.payment.paid,balance_due:inv.payment.balance,note:inv.note},{onConflict:'id'}); if(ir.error) throw ir.error;
      const dr=await sb.from('invoice_items').delete().eq('invoice_id',inv.id); if(dr.error) throw dr.error;
      if(inv.items.length){ const ii=await sb.from('invoice_items').insert(inv.items.map(it=>({id:it.id||crypto.randomUUID(),invoice_id:inv.id,product_id:it.productId||d.products.find(p=>p.name.toLowerCase()===String(it.name).toLowerCase())?.id||null,item_name:it.name,hsn:it.hsn,unit:it.unit,quantity:it.qty,rate:it.rate,discount:it.discount,gst_rate:it.gst,taxable_value:Math.max(0,it.qty*it.rate-it.discount),tax_value:Math.max(0,it.qty*it.rate-it.discount)*it.gst/100,line_total:Math.max(0,it.qty*it.rate-it.discount)*(1+it.gst/100)}))); if(ii.error) throw ii.error; }
    }
    setCloudStatus(true,'Cloud synced');
  }catch(e){ console.error(e); setCloudStatus(false,'Local + sync retry'); }
  finally{ syncing=false; }
}
window.cloudPersist=()=>{ localStorage.setItem(window.KEY,JSON.stringify(window.data)); syncCloud(); };

async function start(){
  window.KEY='adenium_gst_billing_v1';
  // expose the existing classic-script state to this module
  window.data=data;
  const {data:sessionData}=await sb.auth.getSession();
  user=sessionData.session?.user||null;
  sb.auth.onAuthStateChange(async (event,session)=>{
    user=session?.user||null;
    if(event==='PASSWORD_RECOVERY'){
      document.getElementById('recoveryOverlay')?.classList.remove('hide');
      overlay().classList.add('hide');
      return;
    }
    if(user){
      try{ await loadCloud(); overlay().classList.add('hide'); setCloudStatus(true,'Cloud connected'); window.__appSetup(); }
      catch(e){ console.error(e); authMsg('Cloud connection failed: '+e.message,true); }
    } else { overlay().classList.remove('hide'); setCloudStatus(false,'Sign in required'); }
  });
  if(user){
    try{ await loadCloud(); overlay().classList.add('hide'); setCloudStatus(true,'Cloud connected'); window.__appSetup(); }
    catch(e){ console.error(e); authMsg('Cloud connection failed: '+e.message,true); }
  } else overlay().classList.remove('hide');
}
start();
