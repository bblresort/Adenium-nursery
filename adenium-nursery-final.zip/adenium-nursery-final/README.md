# Adenium Nursery Business Suite

Mobile-first business management app for Adenium Nursery, designed as one lean Android/PWA application.

## Core modules
- GST Billing / Sales
- Product Management
- Inventory & Stock Movements
- Customer Management
- Supplier Management
- Purchase Bills
- Quotations / Estimates
- Sales Orders
- Purchase Orders
- Delivery Challans
- GST Reports & CSV export
- Expenses
- Profit & Loss (management view)
- Credit / Outstanding tracking
- Double-entry style management accounting: cash, bank, receivables, payables, sales, purchases, GST input/output, expenses, journal entries, trial balance and management balance sheet
- Settings / business configuration
- AI & HSN Assistant

## AI / HSN design
- Fast local HSN search for common nursery products and services.
- Import an official GSTN HSN/SAC master CSV/Excel-exported CSV for the complete current list.
- Official GSTN Search HSN link is included for verification.
- HSN suggestions are explicitly treated as suggestions, not legally binding classification.
- Optional live AI provider hook can be configured locally; no third-party API secret is bundled in the app.
- Built-in offline knowledge assistant answers common app/GST/business questions even without an AI API.

## Documents
Quotations can convert to Sales Orders; Sales Orders can convert to Delivery Challans or load into GST Billing; Purchase Orders can load into Purchase Bills.

## Accounting
The accounting engine creates management ledger entries from sales, purchases, expenses and payment-in/payment-out activity. It also supports manual journal entries and management-view trial balance, P&L and balance sheet. It is not a statutory accounting/audit opinion system.

## Security
- Supabase Auth + owner-scoped Row Level Security.
- No service/secret key is embedded in frontend code.

## Android
- Capacitor Android configuration included.
- GitHub Actions workflow included to build a debug APK for direct sharing.
- Google Play publication is not required for direct APK distribution.

## Checks completed
- Inline JavaScript syntax check: passed
- cloud.js syntax check: passed
- Navigation/section consistency check: passed
- Supabase security advisor after expanded schema: no security lints
- Supabase performance advisor: only informational unused-index notices on mostly empty tables
- No existing billing data was present in the nursery Supabase project when the expanded schema work was applied

## Important compliance note
GSTN provides a downloadable updated HSN/SAC list and an HSN search facility, and GSTN states that search output is for facilitation and should be verified by the taxpayer. The app follows that model.


## Final QA status
- Static JavaScript syntax: PASS
- Inline handler cross-reference against index.html + cloud.js: PASS
- Duplicate HTML id check: PASS
- Required commercial/accounting/AI sections present: PASS
- Live Supabase schema checked: PASS
- Live Supabase RLS policies checked for all business tables: PASS
- Live Supabase security advisor: no lints
- Android source/build workflow included: YES
- Physical Android APK build in this environment: NOT VERIFIED (Android SDK/Gradle dependencies were unavailable locally).

The packaged project is therefore the final source/build package, not a falsely-labelled prebuilt APK. The included GitHub Actions workflow builds the debug APK on a GitHub-hosted runner.
