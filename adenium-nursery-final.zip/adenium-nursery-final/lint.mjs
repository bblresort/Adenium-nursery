import fs from 'node:fs';
const s=fs.readFileSync('index.html','utf8');
for (const block of s.matchAll(/<script>([\s\S]*?)<\/script>/g)) new Function(block[1]);
console.log('Inline JS syntax: OK');
