-- Adenium Nursery GST Billing core schema
-- Target: the separate Supabase project used for the nursery app.

create extension if not exists pgcrypto;

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null, gstin varchar(15), address text, state text not null default 'Assam', pin varchar(6), phone text,
  invoice_prefix varchar(6) not null default 'AN', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null, hsn varchar(8) not null, unit text not null default 'Nos', rate numeric(14,2) not null default 0 check(rate>=0),
  gst_rate numeric(5,2) not null default 0 check(gst_rate>=0 and gst_rate<=100), active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null, mobile varchar(15), gstin varchar(15), address text, state text, pin varchar(6),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null, invoice_number varchar(16) not null, invoice_date date not null,
  status text not null default 'active' check(status in ('active','cancelled')), cancellation_reason text, cancelled_at timestamptz,
  supply_type text not null check(supply_type in ('intra','inter')), reverse_charge boolean not null default false,
  subtotal numeric(14,2) not null default 0, discount_total numeric(14,2) not null default 0, taxable_total numeric(14,2) not null default 0,
  cgst_total numeric(14,2) not null default 0, sgst_total numeric(14,2) not null default 0, igst_total numeric(14,2) not null default 0,
  grand_total numeric(14,2) not null default 0, payment_mode text not null default 'UPI', amount_paid numeric(14,2) not null default 0 check(amount_paid>=0),
  balance_due numeric(14,2) not null default 0, note text, created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(business_id, invoice_number)
);
create table if not exists public.invoice_items (
  id uuid primary key default gen_random_uuid(), invoice_id uuid not null references public.invoices(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null, item_name text not null, hsn varchar(8) not null, unit text not null default 'Nos',
  quantity numeric(14,3) not null check(quantity>0), rate numeric(14,2) not null default 0 check(rate>=0), discount numeric(14,2) not null default 0 check(discount>=0),
  gst_rate numeric(5,2) not null default 0 check(gst_rate>=0 and gst_rate<=100), taxable_value numeric(14,2) not null default 0,
  tax_value numeric(14,2) not null default 0, line_total numeric(14,2) not null default 0, created_at timestamptz not null default now()
);
create index if not exists idx_businesses_owner on public.businesses(owner_id);
create index if not exists idx_products_business on public.products(business_id);
create index if not exists idx_customers_business on public.customers(business_id);
create index if not exists idx_invoices_business_date on public.invoices(business_id, invoice_date desc);
create index if not exists idx_invoices_business_status_date on public.invoices(business_id, status, invoice_date desc);
create index if not exists idx_invoice_items_invoice on public.invoice_items(invoice_id);

alter table public.businesses enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.invoices enable row level security;
alter table public.invoice_items enable row level security;

create or replace function public.set_updated_at() returns trigger language plpgsql set search_path = pg_catalog, public as $$
begin new.updated_at = pg_catalog.now(); return new; end; $$;

drop trigger if exists businesses_updated_at on public.businesses;
create trigger businesses_updated_at before update on public.businesses for each row execute function public.set_updated_at();
drop trigger if exists products_updated_at on public.products;
create trigger products_updated_at before update on public.products for each row execute function public.set_updated_at();
drop trigger if exists customers_updated_at on public.customers;
create trigger customers_updated_at before update on public.customers for each row execute function public.set_updated_at();
drop trigger if exists invoices_updated_at on public.invoices;
create trigger invoices_updated_at before update on public.invoices for each row execute function public.set_updated_at();

revoke all on public.businesses, public.products, public.customers, public.invoices, public.invoice_items from anon;
grant select, insert, update, delete on public.businesses, public.products, public.customers, public.invoices, public.invoice_items to authenticated;

drop policy if exists "owner businesses" on public.businesses;
create policy "owner businesses" on public.businesses for all to authenticated using ((select auth.uid())=owner_id) with check ((select auth.uid())=owner_id);
drop policy if exists "owner products" on public.products;
create policy "owner products" on public.products for all to authenticated using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid()))) with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));
drop policy if exists "owner customers" on public.customers;
create policy "owner customers" on public.customers for all to authenticated using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid()))) with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));
drop policy if exists "owner invoices" on public.invoices;
create policy "owner invoices" on public.invoices for all to authenticated using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid()))) with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));
drop policy if exists "owner invoice items" on public.invoice_items;
create policy "owner invoice items" on public.invoice_items for all to authenticated using (exists(select 1 from public.invoices i join public.businesses b on b.id=i.business_id where i.id=invoice_id and b.owner_id=(select auth.uid()))) with check (exists(select 1 from public.invoices i join public.businesses b on b.id=i.business_id where i.id=invoice_id and b.owner_id=(select auth.uid())));

-- Safe migration for an existing installation
alter table public.invoices add column if not exists status text not null default 'active';
alter table public.invoices add column if not exists cancellation_reason text;
alter table public.invoices add column if not exists cancelled_at timestamptz;
create index if not exists idx_invoices_business_status_date on public.invoices(business_id, status, invoice_date desc);

-- Expanded commercial documents + accounting schema (v5)
create table if not exists public.suppliers (id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, name text not null, mobile text, gstin text, state text, created_at timestamptz not null default now());
create index if not exists idx_suppliers_business on public.suppliers(business_id);
create table if not exists public.quotes (id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, number text not null, quote_date date not null, party_id uuid, party_name text not null, rows jsonb not null default '[]'::jsonb, total numeric(14,2) not null default 0, status text not null default 'open', source_id uuid, created_at timestamptz not null default now());
create unique index if not exists uq_quotes_business_number on public.quotes(business_id, number);
create table if not exists public.sales_orders (id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, number text not null, order_date date not null, party_id uuid, party_name text not null, rows jsonb not null default '[]'::jsonb, total numeric(14,2) not null default 0, status text not null default 'open', source_quote_id uuid, created_at timestamptz not null default now());
create unique index if not exists uq_sales_orders_business_number on public.sales_orders(business_id, number);
create table if not exists public.purchase_orders (id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, number text not null, order_date date not null, party_id uuid, party_name text not null, rows jsonb not null default '[]'::jsonb, total numeric(14,2) not null default 0, status text not null default 'open', created_at timestamptz not null default now());
create unique index if not exists uq_purchase_orders_business_number on public.purchase_orders(business_id, number);
create table if not exists public.delivery_challans (id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, number text not null, challan_date date not null, party_id uuid, party_name text not null, purpose text, rows jsonb not null default '[]'::jsonb, total numeric(14,2) not null default 0, status text not null default 'open', source_sales_order_id uuid, created_at timestamptz not null default now());
create unique index if not exists uq_delivery_challans_business_number on public.delivery_challans(business_id, number);
create table if not exists public.purchases (id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, number text not null, purchase_date date not null, supplier_id uuid, supplier_name text not null, rows jsonb not null default '[]'::jsonb, total numeric(14,2) not null default 0, balance numeric(14,2) not null default 0, status text not null default 'active', created_at timestamptz not null default now());
create unique index if not exists uq_purchases_business_number on public.purchases(business_id, number);
create table if not exists public.expenses (id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, expense_date date not null, category text not null, amount numeric(14,2) not null default 0, mode text not null default 'Cash', note text, created_at timestamptz not null default now());
create table if not exists public.accounts (id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, account_key text not null, name text not null, type text not null, opening numeric(14,2) not null default 0, created_at timestamptz not null default now());
create unique index if not exists uq_accounts_business_key on public.accounts(business_id, account_key);
create table if not exists public.journal_entries (id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, entry_date date not null, description text not null, debit_account text not null, credit_account text not null, amount numeric(14,2) not null default 0, ref text, created_at timestamptz not null default now());

alter table public.suppliers enable row level security;
alter table public.quotes enable row level security;
alter table public.sales_orders enable row level security;
alter table public.purchase_orders enable row level security;
alter table public.delivery_challans enable row level security;
alter table public.purchases enable row level security;
alter table public.expenses enable row level security;
alter table public.accounts enable row level security;
alter table public.journal_entries enable row level security;

-- Current live-schema reconciliation (v7 QA)
-- These statements make the packaged schema match the live nursery project.
alter table public.products add column if not exists stock numeric(14,3) not null default 0;
alter table public.products add column if not exists reorder_level numeric(14,3) not null default 5;
create table if not exists public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  quantity_change numeric(14,3) not null,
  reason text not null default 'Manual adjustment',
  movement_date date not null default current_date,
  created_at timestamptz not null default now()
);
create index if not exists idx_stock_movements_business on public.stock_movements(business_id, movement_date desc);
create index if not exists idx_stock_movements_product on public.stock_movements(product_id, movement_date desc);
alter table public.stock_movements enable row level security;
revoke all on public.stock_movements from anon;
grant select, insert, update, delete on public.stock_movements to authenticated;
drop policy if exists "owner stock movements" on public.stock_movements;
create policy "owner stock movements" on public.stock_movements for all to authenticated
using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())))
with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));

-- Expanded business tables are owner-scoped and authenticated-only.
revoke all on public.suppliers, public.quotes, public.sales_orders, public.purchase_orders,
  public.delivery_challans, public.purchases, public.expenses, public.accounts, public.journal_entries from anon;
grant select, insert, update, delete on public.suppliers, public.quotes, public.sales_orders, public.purchase_orders,
  public.delivery_challans, public.purchases, public.expenses, public.accounts, public.journal_entries to authenticated;

alter table public.suppliers enable row level security;
drop policy if exists "owner suppliers" on public.suppliers;
create policy "owner suppliers" on public.suppliers for all to authenticated
using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())))
with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));

alter table public.quotes enable row level security;
drop policy if exists "owner quotes" on public.quotes;
create policy "owner quotes" on public.quotes for all to authenticated
using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())))
with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));

alter table public.sales_orders enable row level security;
drop policy if exists "owner sales orders" on public.sales_orders;
create policy "owner sales orders" on public.sales_orders for all to authenticated
using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())))
with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));

alter table public.purchase_orders enable row level security;
drop policy if exists "owner purchase orders" on public.purchase_orders;
create policy "owner purchase orders" on public.purchase_orders for all to authenticated
using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())))
with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));

alter table public.delivery_challans enable row level security;
drop policy if exists "owner delivery challans" on public.delivery_challans;
create policy "owner delivery challans" on public.delivery_challans for all to authenticated
using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())))
with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));

alter table public.purchases enable row level security;
drop policy if exists "owner purchases" on public.purchases;
create policy "owner purchases" on public.purchases for all to authenticated
using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())))
with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));

alter table public.expenses enable row level security;
drop policy if exists "owner expenses" on public.expenses;
create policy "owner expenses" on public.expenses for all to authenticated
using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())))
with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));

alter table public.accounts enable row level security;
drop policy if exists "owner accounts" on public.accounts;
create policy "owner accounts" on public.accounts for all to authenticated
using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())))
with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));

alter table public.journal_entries enable row level security;
drop policy if exists "owner journal entries" on public.journal_entries;
create policy "owner journal entries" on public.journal_entries for all to authenticated
using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())))
with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=(select auth.uid())));

